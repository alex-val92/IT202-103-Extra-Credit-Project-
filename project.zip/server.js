let express = require("express");
let app = express();

app.use(express.urlencoded({ extended: true }));

let productlist = [
  { id: 1, image: "/img/a.png", name: "Akali", detail: "TOP", price: 10, stock: 10 },
  { id: 2, image: "/img/b.png", name: "Evelynn", detail: "JUG", price: 15, stock: 10 },
  { id: 3, image: "/img/c.png", name: "Ahri", detail: "MID", price: 20, stock: 10 },
  { id: 4, image: "/img/d.png", name: "Kai'Sa", detail: "BOT", price: 25, stock: 10 },
  { id: 5, image: "/img/e.png", name: "Seraphine", detail: "SUP", price: 30, stock: 10 }
];

let orderlist = {};
let ordercount = 10000;

app.use("/frontend", express.static(__dirname + "/frontend"));
app.use("/img", express.static(__dirname + "/img"));

app.get("/", function (req, res) {
  res.redirect("/frontend/index.html");
});

app.get("/products.js", function (req, res) {
  res.set("Content-Type", "application/javascript");
  res.send("var productlist = " + JSON.stringify(productlist) + ";");
});

function getProd(pid) {
  for (let i = 0; i < productlist.length; i++) {
    if (productlist[i].id == pid) {
      return productlist[i];
    }
  }
  return null;
}

app.post("/checkout", function (req, res) {
  let cart = [];
  try {
    cart = JSON.parse(req.body.cart);
  } catch (e) {
    cart = [];
  }

  let finalItems = [];

  for (let i = 0; i < cart.length; i++) {
    let c = cart[i];
    let prod = getProd(c.id);
    if (!prod) continue;

    let cnt = c.count;
    if (cnt > prod.stock) cnt = prod.stock;

    prod.stock = prod.stock - cnt;

    finalItems.push({
      id: prod.id,
      name: prod.name,
      price: prod.price,
      image: prod.image,
      count: cnt
    });
  }

  ordercount++;
  orderlist[ordercount] = {
    ordernumber: ordercount,
    address: req.body.address,
    items: finalItems
  };

  res.redirect("/frontend/bill.html?order=" + ordercount);
});

app.get("/order.js", function (req, res) {
  let info = orderlist[req.query.order];
  res.set("Content-Type", "application/javascript");
  res.send("var orderinfo = " + JSON.stringify(info) + ";");
});

app.listen(3000);
